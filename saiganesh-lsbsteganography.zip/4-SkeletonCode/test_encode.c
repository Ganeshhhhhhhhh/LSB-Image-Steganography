#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>
//#include <stdarg.h>
#include <stdlib.h>

//OperationType check_operation_type(char *argv[]);
//Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);

int main(int argc,char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo dncInfo;
    uint img_size;

	//validation
    if(argc>=3)
    {
		//check whether the selected operation is encode or decode
        if(check_operation_type(argv) == e_encode)
        {
            printf("Selected encoding\n");
            if(read_and_validate_encode_args(argv,&encInfo) == e_success)
            {
                printf("Read and Validate success\n");
                if(do_encoding(&encInfo) == e_success)
                {
                    printf("Encoding Successfull\n");
                }
                else
                {
                    printf("Encoding failure\n");
                }
            }
            else
            {
                printf("failed to read and validate\n");
                exit(0);
            }
        }
        else if(check_operation_type(argv) == e_decode)
        {
            printf("Selected decoding\n");
            if(read_and_validate_decode_args(argv,&dncInfo) == d_success)
            {
                printf("Read and Validate success\n");
                if(do_decoding(&dncInfo) == d_success)
                {
                    printf("Decoding Successfull\n");
                }
                else
                {
                    printf("Decoding failure\n");
                }
            }
            else
            {
                printf("failed to read and validate\n");
				exit(0);
            }
        }
        else
        {
            printf("Unsupported operation\nUsage: ./lsb_steg: Encoding: ./lsb_steg -e <.bmp file> <.txt file> [output file]\n");
		   	exit(0);	
        }
    }
	//if arguments passed is not matching print usage
    else
    {
		printf("Usage: ./lsb_steg: Encoding: ./lsb_steg -e <.bmp file> <.txt tile> [output file]\n");
        printf("Usage: ./lsb_steg: Decoding: ./lsb_steg -d <.bmp file> [output file]\n");
    }
    return 0;
}

////function to check whether the selected operation is encoding or decoding
OperationType check_operation_type(char *argv[])
{
	//based on argv[1] return encode or decode
    if(strcmp(argv[1],"-e")==0)
    {
        return e_encode;
    }
    else if(strcmp(argv[1],"-d")==0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}


