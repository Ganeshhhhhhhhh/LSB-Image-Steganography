#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"
#include <stdarg.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    //check source file is  bmp or not
    if(strstr(argv[2],".bmp")!=NULL)
    {
        //store source file name
        encInfo->src_image_fname = argv[2];
        //printf("SRC IMG STORED\n");
        //store secret file name
        encInfo->secret_fname = argv[3];

        //search for secret  file extension and store it in extension file
        strcpy(encInfo -> extn_secret_file,strchr(encInfo -> secret_fname, '.'));
        //check if output file name is passed and store it in a file   
        if(argv[4])
        {
            encInfo -> stego_image_fname = argv[4];
        }
        else
        {
            encInfo -> stego_image_fname = "output.bmp";
        }
        return e_success;
    }
	//if bmp file is not passed
    else
    {
        printf("Unsupported extension file\n Usage: use .bmp extension file as source file");
        return e_failure;
    }
}
Status do_encoding(EncodeInfo *encInfo)
{
	//to open file
    if(open_files(encInfo) == e_success)
    {
        printf("Open files successfull\n");
    }
    else
    {
        printf("Encoding failure\n");
        return e_failure;
    }

	//check capacity of source file
    if(check_capacity(encInfo) == e_success)
    {
        printf("Sorted capacity\n");
    }
    else
    {
        printf("Capacity not sorted\n");
        return e_failure;
    }

	//check whether bmp header is copied
    if(copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
    {
        printf("Copying bmp header successfull\n");    
    }
    else
    {
        printf("Copying bmp header unsuccessfull\n");
        return e_failure;
    }

	//check whether magic string is encoded
    if(encode_magic_string(MAGIC_STRING,encInfo) == e_success)
    {
        printf("Encoding of magic string successfull\n");
    }
    else
    {
        printf("Encoding of magic string unsuccessfull\n");
        return e_failure;
    }

	//encoding size of extension of secret file
	if(encode_file_size(strlen(encInfo -> extn_secret_file), encInfo) == e_success)
	{
		printf("Size of secret file extension is fetched successfully\n");
	}
	else
	{
		printf("Size of secret file extension is not fetched successfully\n");
		return e_failure;
	}

	//encoding of secret file extension
    if(encode_secret_file_extn(encInfo -> extn_secret_file,encInfo) == e_success)
    {
        printf("Encoding secret file extension successfull\n");
    }
    else
    {
        printf("Encoding secret file extension unsuccessfull\n");
        return e_failure;
    }

	//to get secret file size
    if(encode_file_size(get_file_size(encInfo -> fptr_secret),encInfo) == e_success)
    {
        printf("Encoding secret file size successfull\n");
    }
    else
    {
        printf("Encoding secret file size unsucessfull\n");
        return e_failure;
    }

	//to encode secret file data
    if(encode_secret_file_data(encInfo) == e_success)
    {
        printf("Encoding file data successfull\n");
    }
    else
    {
        printf("Encoding file data unsuccessfull\n");
        return e_failure; 
    }

	//to copy remaining data to stego image 
    if(copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
    {
        printf("Copying remaining image data successfull\n");
    }
    else
    {
        printf("Copying remaining image data unsuccessfull\n");
        return e_failure;
    }
    return e_success;

}
Status check_capacity(EncodeInfo *encInfo)
{
	//check whether the total size required to encode is greater than or equal to size of source file
    if(get_image_size_for_bmp(encInfo -> fptr_src_image)>=54+(strlen(MAGIC_STRING)+4+ strlen(encInfo -> extn_secret_file)+4+get_file_size(encInfo -> fptr_secret))*8)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

//to get file size using ftell
uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);
    unsigned int size = ftell(fptr);
    rewind(fptr);
    return size;
}

//to copy bmp header till 54th position
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char arr[55];

    rewind(fptr_dest_image);
    rewind(fptr_src_image);
    fread(arr,54,1,fptr_src_image);
    fwrite(arr,54,1,fptr_dest_image);
    
    if(ftell(fptr_dest_image) == 54)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

//to encode magic string 
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    if(encode_data_to_image(MAGIC_STRING,strlen(magic_string),encInfo -> fptr_src_image,encInfo -> fptr_stego_image) == e_success)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

//to encode byte to lsb
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for(int i=0;i<8;i++)
    {
        image_buffer[i] = (image_buffer[i] & (~1)) | ((data >> i) & 1);
    }
}

//to encode data to image
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char arr[8];

    for(int i=0;i<size;i++)
    {
        fread(arr,8,1,fptr_src_image);
        encode_byte_to_lsb(data[i],arr);
        fwrite(arr,8,1,fptr_stego_image);
    }
    return e_success;
}

//to encode file size of secret file and extension size
Status encode_file_size(long file_size, EncodeInfo *encInfo)
{
    char arr[32];

    fread(arr,32,1, encInfo->fptr_src_image);
    for(int i=0;i<32;i++)
    {
        arr[i] = (arr[i] & (~1)) | ((file_size >> i) & 1);
    }
    fwrite(arr,32,1,encInfo->fptr_stego_image);
    return e_success;
}

//to encode secret file extension
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn,strlen(file_extn),encInfo -> fptr_src_image,encInfo -> fptr_stego_image);
    return e_success;
}

//to encode secret file data
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    int size = get_file_size(encInfo -> fptr_secret);
    for(int i=0;i<size;i++)
    {
        fread(encInfo -> secret_data,1,1,encInfo -> fptr_secret);
        encode_data_to_image(encInfo->secret_data,1,encInfo -> fptr_src_image,encInfo -> fptr_stego_image);
    }
    return e_success;
}

//to copy remaining data of image
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char arr; 
    while(fread(&arr,1,1,fptr_src))
    {
        fwrite(&arr,1,1,fptr_dest);
    }
    return e_success;
}





        




