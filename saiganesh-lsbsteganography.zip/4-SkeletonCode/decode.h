#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * decoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /* Secret File Info */
    char *output_fname;
    FILE *fptr_out;
    char extn_output_file[MAX_FILE_SUFFIX + 1];
    char output_data[MAX_SECRET_BUF_SIZE];
    int size_output_file;
    int extn_size;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

}DecodeInfo;

/* Decoding function prototype */

//to open stego file
Status(open_stego_file(DecodeInfo *dncInfo));

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *dncInfo);

//to decode the stego image
Status do_decoding(DecodeInfo *dncInfo);

//to decode magic string
Status decode_magicstring(int len ,DecodeInfo *dncInfo);

//to decode extension size
Status decode_extn_size(DecodeInfo *dncInfo);

//to decode extension file
Status decode_output_extn(DecodeInfo *dncInfo);

//to decode output file size
Status output_file_size(DecodeInfo *dncINfo);

//to decode output file 
Status decode_output_file_data(DecodeInfo *dncInfo);

//to open output file
Status open_output_file(DecodeInfo *dncInfo);

//to decode byte from lsb
Status decode_byte_from_lsb(char *data,DecodeInfo *dncInfo);

//to decode size from lsb
Status decode_size_from_lsb(int *size, DecodeInfo *dncInfo);

//to decode data from image
Status decode_data_from_image(int size, FILE *fptr, DecodeInfo *dncInfo);

#endif


