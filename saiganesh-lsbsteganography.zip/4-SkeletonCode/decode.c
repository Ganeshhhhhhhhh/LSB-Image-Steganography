#include <stdio.h>
#include "decode.h"
#include "types.h"
#include <string.h>
#include "common.h"
#include <stdarg.h>

//to open stego image and point the pointer to 55th position
Status open_stego_file(DecodeInfo *dncInfo)
{
    dncInfo->fptr_stego_image = fopen(dncInfo-> stego_image_fname, "r");

    fseek(dncInfo -> fptr_stego_image,54,SEEK_SET);

    if (dncInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n",dncInfo->stego_image_fname);

        return d_failure;
    }
    return d_success;
}

//read and validate arguments
Status read_and_validate_decode_args(char *argv[], DecodeInfo *dncInfo)
{
    if(strstr(argv[2],".bmp")!=NULL)
    {
        dncInfo -> stego_image_fname = argv[2];
        if(argv[3])
        {
            dncInfo -> output_fname = argv[3];
        }
        else
        {
            dncInfo -> output_fname = "dncoutput";
        }
        return d_success;
    }
    else
    {
        printf("Please pass .bmp file\nUsage: ./lsb_steg: Decoding: ./lsb_steg -d <.bmp file> [output file]\n");
    }
    return d_failure;
}

//decoding function
Status do_decoding(DecodeInfo *dncInfo)
{
	//open stego image
    if(open_stego_file(dncInfo) == d_success)
    {
        printf("Opened image successfully\n");
    }
    else
    {
        printf("Failed to open image\n");
        return d_failure;
    }

	//decode magic string
    if(decode_magicstring(strlen(MAGIC_STRING),dncInfo) == d_success)
    {
        printf("Decoding magic string successfull\n");
    }
    else
    {
        printf("Decoding of magic string unsuccessfull\n");
        return d_failure;
    }

	//decode size of output extension
    if(decode_extn_size(dncInfo) == d_success)
    {
        printf("Decoding of extension size successfull\n");
    }
    else
    {
        printf("Decoding of extension size unsuccessfull\n");
        return d_failure;
    }

	//to decode output extension
    if(decode_output_extn(dncInfo) == d_success)
    {
        printf("Decoding output extension successfull\n");
    }
    else
    {
        printf("Decoding output extension unsuccessfull\n");
        return d_failure;
    }

	//to open output file	
	if(open_output_file(dncInfo) == d_success)
	{
		printf("Output file opened successfully\n");
	}
	else
	{
		printf("Output file not opened\n");
		return d_failure;
	}

	//to get output file size
    if(output_file_size(dncInfo) == d_success)
    {
        printf("Output file size fetched successfully\n");
    }
    else
    {
        printf("Output file size fetched unsuccessfully\n");
        return d_failure;
	}

	//to decode output file data
    if(decode_output_file_data(dncInfo) == d_success)
    {
        printf("Decoding output file successfull\n");
    }
    else
    {
        printf("Decoding output file unsuccessfull\n");
        return d_failure;
    }
	return d_success;
}

//magic string decoding
Status decode_magicstring(int len,DecodeInfo *dncInfo)
{
    char magic_string[len+1];
    char arr[8];
    int i;
    for(i=0;i<len;i++)
    {
        decode_byte_from_lsb(&magic_string[i],dncInfo);
    }
    magic_string[i]='\0';

    printf("The decoded magic string is %s\n",magic_string);
    if(strcmp(MAGIC_STRING,magic_string) == 0)
    {   
        return d_success;
    }
    else
    {
        return d_failure;
    }
}

//decode extension size
Status decode_extn_size(DecodeInfo *dncInfo)
{
	dncInfo->extn_size = 0;
    decode_size_from_lsb(&(dncInfo -> extn_size),dncInfo);
    printf("Extension size is %d\n",dncInfo -> extn_size);
    return d_success;
}

//decode output extension
Status decode_output_extn(DecodeInfo *dncInfo)
{
    int i;
    printf("The output file extension is :");
    for(i=0;i< dncInfo -> extn_size;i++)
    {
        decode_byte_from_lsb(&(dncInfo -> extn_output_file[i]),dncInfo);
        printf("%c",dncInfo -> extn_output_file[i]);
    }
    dncInfo -> extn_output_file[i] ='\0';
	printf("\n");
    return d_success;
}

//open output file
Status open_output_file(DecodeInfo *dncInfo)
{
    char name[20]={0};
    strcat(name,dncInfo -> output_fname);
    strcat(name,dncInfo -> extn_output_file);
    dncInfo -> fptr_out = fopen(name,"w");
    rewind(dncInfo -> fptr_out);
    if(dncInfo -> fptr_out != NULL)
    {
        return d_success;
    }
    else
    {
        return d_failure;
    }
}

//to get output file size
Status output_file_size(DecodeInfo *dncInfo)
{
    decode_size_from_lsb(&(dncInfo -> size_output_file),dncInfo);
    printf("Output file size is %d\n",dncInfo -> size_output_file);
    return d_success;
}

//decode output file data
Status decode_output_file_data(DecodeInfo *dncInfo)
{
	decode_data_from_image(dncInfo -> size_output_file, dncInfo -> fptr_out,dncInfo);
    return d_success;
}

//decode data from image
Status decode_data_from_image(int size,FILE *fptr,DecodeInfo *dncInfo)
{
    char bt;
    for(int i=0;i<size;i++)
    {
        decode_byte_from_lsb(&bt,dncInfo);
        fwrite(&bt,1,1,fptr);
    }
    return d_success;
}

//decode byte from lsb
Status decode_byte_from_lsb(char *data, DecodeInfo *dncInfo)
{
    *data=0;
    char image_buffer[8];

    fread(image_buffer,8,1,dncInfo -> fptr_stego_image);
    for(int i=0;i<8;i++)
    {
        *data = ((image_buffer[i] & 1)<<i) | *data;
    }
    return d_success;
}

//decode size from lsb
Status decode_size_from_lsb(int *size, DecodeInfo *dncInfo)
{
    int data=0;
    char image_buffer[32];
    fread(image_buffer,32,1,dncInfo -> fptr_stego_image);
    for(int i=0;i<32;i++)
    {
		
        *size =((image_buffer[i] & 1)<<i) | *size;
    }
    return d_success;
}



